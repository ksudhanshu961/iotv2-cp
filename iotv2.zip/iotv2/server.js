const express=require("express");
const bodyParser=require("body-parser");
const fs = require('fs');
const fileUpload = require('express-fileupload')
const mysql = require('mysql');
const ejs = require('ejs')
const app=express();
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));
var db=['0','0','0','0','0','0','0'];

let conn = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "",
  database: "db_workfiles"
});
conn.connect(function(err) {
  if (err) throw err;
  console.log("Connected!");
});

app.use(fileUpload())

app.set('view engine', 'ejs');

let domain = "127.0.0.1:3000";

var uidsarr = [];
var filenamearr = [];
var dlinkarr = [];

// getData function starts
// Function to fetch data from database
function getData(){
  var sql = "SELECT uids FROM shareddata";
  sql = mysql.format(sql);
  conn.query(sql, function (err, result) {
  if (err) throw err;
  let temparr = JSON.stringify(result);
  let uidsobj = JSON.parse(temparr);
  for(j in uidsobj){
    uidsarr.push(uidsobj[j].uids);
}
});

  var sql = "SELECT filename FROM shareddata";
  sql = mysql.format(sql);
  conn.query(sql, function (err, result) {
  if (err) throw err;
  let temparr = JSON.stringify(result);
  let flnmeobj = JSON.parse(temparr);
  for(j in flnmeobj){
    filenamearr.push(flnmeobj[j].filename);
}
});

  var sql = "SELECT dlinks FROM shareddata";
  sql = mysql.format(sql);
  conn.query(sql, function (err, result) {
  if (err) throw err;
  let temparr = JSON.stringify(result);
  let dlinkobj = JSON.parse(temparr);
  for(m in dlinkobj){
    dlinkarr.push(dlinkobj[m].dlinks);
}
});
}
// getData function ends


//insertData function starts
// Function to insert data into database
function insertData(uids, filename, dlink){
  var sql = "INSERT INTO shareddata (uids, filename, dlinks) VALUES (?, ?, ?)";
  var inserts = [uids, filename, dlink];
  sql = mysql.format(sql, inserts);
  conn.query(sql, function (err, result) {
  if (err) throw err;
  });

}
//insertData function ends


app.get("/", (req,res)=>{
  res.json(db);
});

app.get("/add/:id", (req,res)=>{
  id=parseInt(req.params.id);

  if(db[id]=='0'){
  db[id]='1';
}
  else {
     db[id]='0';
   }
console.log(db[id]);
res.json(db[id]);


});
app.get("/bmi", function(req,res){
  res.sendFile(__dirname+"/index.html")

});

// submit data index
app.get("/submit-data", (req, res)=>{
  getData();
  res.render("upload", {uids: uidsarr, filenames:filenamearr, dlinks:dlinkarr});
  uidsarr = [];
  filenamearr = [];
  dlinkarr = [];
});

// Downloads route
app.get("/download/:fdName", (req, res)=>{
  let file = req.params.fdName
  let path = __dirname+'/uploads/'+file;
  if(fs.existsSync(path)){
    res.download(path);
  }
  else{
    res.send("<script>alert('File not exists..!')</script>")
  };
});


// Accepting and pushing data to database.
app.post("/", (req, res)=>{
  let subject = req.body.subject;
  let name = req.body.name;
  if(subject === '' || name === ''){
    res.redirect("/");
  }
  else if(req.files){
    let uids = req.body.uids;
    let file = req.files.wfile;
    let filename = file.name;
    if(fs.existsSync(__dirname+'/uploads/'+filename)){
      res.send("<script>alert('File Already Exists..!')</script>")
    }
    else{
      file.mv(__dirname+'/uploads/'+filename, function(err){
        res.send(err);
      });
      let dlink = 'http://'+domain+'/download/'+filename;
      insertData(uids, filename, dlink);
            res.send('<h1 style="text-align: center">Thank you for Contribution..!</h1><br><br><h3 style="text-align: center">Return <span><a href="/submit-data"> Home</a></span>');
    }
  }
else{
  res.redirect("/");
}
});






app.listen(3000);
